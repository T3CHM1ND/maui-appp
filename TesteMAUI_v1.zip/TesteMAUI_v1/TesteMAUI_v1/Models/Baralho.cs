﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesteMAUI_v1.Models
{
    public abstract class Baralho
    {
        public string NomeBaralho { get; set; }
        public int CodBaralho { get; set; }
        public int CodAutorUser { get; set; }
        public string Tema { get; set; }
        public int CodEstilo { get; set; }


    }
}
