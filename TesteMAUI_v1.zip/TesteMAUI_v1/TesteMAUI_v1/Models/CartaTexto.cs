﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesteMAUI_v1.Models
{
    public class CartaTexto: Carta
    {
        public string texto {  get; set; }
        
        //anexarCarta() editarCarta() mostrarCarta(): void

    }
}
