﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesteMAUI_v1.Models
{
    public class Carta
    {
        public string NomeCarta { get; set; }
        public int CodCarta { get; set; }
        public int CodBaralho { get; set; }

        //editarCarta(): void
        //mostrarCarta(): void
    }
}
//git clone ou git forc
