﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesteMAUI_v1.Models
{
    public class EstiloBaralho
    {
        public int CodEstilo { get; set; }
        public string NomeEstilo { get; set; }
        public int Valor {  get; set; }

        public void comprarEstilo() { }
        public void utilizarEstilo() { }

    }
}
